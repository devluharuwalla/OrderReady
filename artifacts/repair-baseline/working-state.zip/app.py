"""OrderReady intake UI. Run with python -m streamlit run app.py."""
from copy import deepcopy
import hashlib
import inspect
import os
import re

import streamlit as st
import fixtures
import model
from model import FIELDS, extract_order
from order_logic import GARMENT, PRINT_LOCATION, SIZES, render_ticket, ticket_json, validate
from ui_state import cache_get, cache_put, extraction_key

SERVICE = f"{GARMENT} · Sizes S / M / L · {PRINT_LOCATION} print"
NONCOMMITMENT = ("This intake ticket is not a quote, a confirmed order, or a promise "
                 "that the deadline can be met.")
UNAVAILABLE_MESSAGE = "Live AI unavailable. Manual entry is ready."
FIELD_LABEL = {"customer_name": "Customer name", "contact": "Email or phone",
               "sizes": "Size quantities", "deadline": "Deadline", "stated_total": "Requested quantity"}
EDIT_KEYS = ["customer_name", "contact", "size_S", "size_M", "size_L", "deadline", "stated_total"]


def empty_extraction():
    return {"fields": {n: {"value": None, "evidence": None} for n in FIELDS},
            "ambiguities": [], "dropped": [], "error": None}


def live_ai_configured():
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def format_sizes(value):
    if not isinstance(value, dict):
        return str(value)
    return " · ".join(f"{s} {value.get(s) if value.get(s) is not None else 'unknown'}" for s in SIZES)


def display_value(name, value):
    return format_sizes(value) if name == "sizes" else value


def readable_extraction(extraction):
    copied = deepcopy(extraction)
    field = copied["fields"].get("sizes", {})
    if field.get("value") is not None:
        field["value"] = format_sizes(field["value"])
    return copied


def _norm(text):
    return " ".join(str(text).split()).lower()


def _topic(text):
    text = _norm(text)
    if any(k in text for k in ("sum", "add up", "adds up", "match", "conflict", "differ", "disagree")) and any(k in text for k in ("size", "total", "shirt")):
        return "total_mismatch"
    for topic, words in (("deadline", ("deadline", "date", "year")),
                         ("sizes", ("size", "small", "medium", "large")),
                         ("contact", ("email", "phone", "contact")),
                         ("customer_name", ("name",))):
        if any(word in text for word in words):
            return topic
    return None


def dedupe_questions(blocks, questions):
    topics = {_topic(block) for block in blocks} - {None}
    seen = {_norm(block) for block in blocks}
    output = []
    for question in questions:
        if _norm(question) not in seen and _topic(question) not in topics:
            output.append(question)
            seen.add(_norm(question))
    return output


def initialize():
    defaults = {"source_text": "", "mode": None, "draft_source": None, "stale": False,
                "reviewed": False, "prepared": None, "history": [], "active_history": None,
                "active_issues": [], "issue_generation": 0, "issue_resolutions": {},
                "extraction": empty_extraction(), "extraction_error": None, "prepare_error": None,
                "pending": None, "source_revision": 0, "request_counter": 0,
                "extraction_cache": {}, "cache_notice": None, "initial_editor": {},
                "observed_snapshot": None}
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)
    for key in EDIT_KEYS:
        st.session_state.setdefault(f"edit_{key}", "")


def invalidate():
    st.session_state.reviewed = False
    st.session_state.prepared = None
    st.session_state.prepare_error = None


def source_changed():
    invalidate()
    st.session_state.source_revision += 1
    st.session_state.cache_notice = None
    if st.session_state.mode is not None:
        st.session_state.stale = True


def issue_key(question):
    digest = hashlib.sha256(str(question).encode()).hexdigest()[:16]
    return f"resolved_{st.session_state.issue_generation}_{digest}"


def resolve_issue(key):
    st.session_state.issue_resolutions[key] = st.session_state.get(key) is True
    invalidate()


def current_overrides():
    """Every editor is authoritative, including a cleared field."""
    typed, errors = {}, []
    for name in ("customer_name", "contact", "deadline"):
        typed[name] = st.session_state[f"edit_{name}"].strip() or None
    raw = st.session_state.edit_stated_total.strip()
    typed["stated_total"] = None
    if raw:
        try:
            typed["stated_total"] = int(raw)
        except ValueError:
            errors.append("Requested quantity must be a whole number.")
    counts = {}
    for size in SIZES:
        raw = st.session_state[f"edit_size_{size}"].strip()
        if not raw:
            continue
        try:
            counts[size] = int(raw)
        except ValueError:
            errors.append(f"Size {size} must be a whole number.")
    typed["sizes"] = counts if len(counts) == len(SIZES) else None
    return typed, errors


def founder_edits(extraction, typed):
    return {name: value for name, value in typed.items()
            if value != extraction["fields"].get(name, {}).get("value")}


def validation_input():
    typed, errors = current_overrides()
    copied = deepcopy(st.session_state.extraction)
    # The public validator ignores None overrides. Clear the copied proposal too.
    for name, value in typed.items():
        if value is None:
            copied["fields"][name]["value"] = None
    return copied, founder_edits(st.session_state.extraction, typed), errors


def review_status():
    state = st.session_state
    copied, overrides, errors = validation_input()
    result = validate(copied, overrides)
    questions = dedupe_questions([], result["questions"])
    unresolved = [q for q in questions if (state.issue_resolutions.get(issue_key(q)) is not True or state.get(issue_key(q), True) is not True)]
    ready = (state.mode in ("manual", "live_ai") and bool(state.source_text.strip())
             and state.draft_source == state.source_text and not state.stale
             and not state.pending and not errors and result["ok"]
             and not unresolved and state.reviewed is True)
    return result, errors, questions, unresolved, ready


def snapshot():
    state = st.session_state
    return {"source_text": state.source_text, "mode": state.mode,
            "editor": {key: state[f"edit_{key}"] for key in EDIT_KEYS},
            "issue_generation": state.issue_generation, "resolutions": dict(state.issue_resolutions)}


def begin_draft(extraction, mode):
    state = st.session_state
    invalidate()
    state.mode = mode
    state.extraction = deepcopy(extraction)
    state.draft_source = state.source_text
    state.stale = False
    state.issue_generation += 1
    state.issue_resolutions = {}
    state.active_issues = list(extraction.get("ambiguities") or [])
    for key in EDIT_KEYS:
        state[f"edit_{key}"] = ""
    for name in FIELDS:
        value = extraction["fields"].get(name, {}).get("value")
        if value is None:
            continue
        if name == "sizes" and isinstance(value, dict):
            for size in SIZES:
                state[f"edit_size_{size}"] = "" if value.get(size) is None else str(value[size])
        elif name != "sizes":
            state[f"edit_{name}"] = str(value)
    state.initial_editor = snapshot()["editor"]


def has_edits():
    state = st.session_state
    return state.mode is not None and snapshot()["editor"] != state.initial_editor


def start_manual():
    state = st.session_state
    if state.prepared or state.pending or not state.source_text.strip():
        return
    if state.mode is not None and state.draft_source == state.source_text:
        invalidate()
        state.mode = "manual"
        state.stale = False
    else:
        begin_draft(empty_extraction(), "manual")
        state.active_history = None
    state.extraction_error = None
    state.cache_notice = None


def cache_key(source):
    fingerprint = hashlib.sha256((model.PROMPT + repr(model.FIELDS) + inspect.getsource(model._call)).encode()).hexdigest()
    return extraction_key(source, model.API_URL, model.MODEL,
                          {"max_tokens": 1000, "timeout": 20}, fingerprint)


def run_extraction(fresh=False, replace=False):
    """Callbacks only enqueue. Rendering owns the one request."""
    state = st.session_state
    if state.prepared or state.pending or not state.source_text.strip() or not live_ai_configured():
        return
    if has_edits() and not replace:
        return
    invalidate()
    state.request_counter += 1
    state.pending = {"id": state.request_counter, "source": state.source_text,
                     "revision": state.source_revision, "fresh": fresh, "key": cache_key(state.source_text)}
    state.cache_notice = None
    state.extraction_error = None


def safe_failure(error):
    text = str(error).lower()
    if re.search(r"http\s+40[13]\b", text):
        return "The AI service rejected its credentials. Use manual entry or check configuration."
    if re.search(r"http\s+429\b", text):
        return "The AI service is busy or rate limited. Retry later or use manual entry."
    if "timeout" in text or "timed out" in text:
        return "The AI request timed out. Retry or use manual entry."
    if "json" in text:
        return "The AI response could not be read. Retry or use manual entry."
    return "The AI request failed. Retry or use manual entry. Your draft has been kept."


def consume_pending():
    state = st.session_state
    intent = state.pending
    if not intent or intent.get("consumed"):
        return
    intent["consumed"] = True
    try:
        proposal = None if intent["fresh"] else cache_get(state.extraction_cache, intent["key"])
        reused = proposal is not None
        if proposal is None:
            proposal = extract_order(intent["source"])
        if (state.pending is not intent or state.request_counter != intent["id"]
                or state.source_revision != intent["revision"] or state.source_text != intent["source"]):
            return
        if proposal.get("error"):
            state.extraction_error = safe_failure(proposal["error"])
            return
        if not isinstance(proposal.get("fields"), dict) or any(not isinstance(proposal["fields"].get(n), dict) for n in FIELDS):
            raise ValueError("Malformed proposal")
        if not reused:
            cache_put(state.extraction_cache, intent["key"], proposal)
        state.history.append({"source_text": intent["source"], "extraction": deepcopy(proposal)})
        begin_draft(proposal, "live_ai")
        state.active_history = len(state.history) - 1
        if reused:
            state.cache_notice = "Reused this session's extraction. No new AI request was made."
    except Exception as error:
        if (state.pending is intent and state.request_counter == intent["id"]
                and state.source_revision == intent["revision"] and state.source_text == intent["source"]):
            state.extraction_error = safe_failure(error)
    finally:
        if state.pending is intent:
            state.pending = None


def load_sample(samples):
    if st.session_state.prepared or st.session_state.pending:
        return
    st.session_state.source_text = samples[st.session_state.sample_choice]["input"]
    source_changed()


def reset():
    for key in list(st.session_state):
        del st.session_state[key]
    initialize()


def acknowledgment_changed():
    st.session_state.prepared = None
    st.session_state.prepare_error = None


def prepare_ticket():
    result, _, _, _, ready = review_status()
    if not ready:
        invalidate()
        st.session_state.prepare_error = "Complete the fields and resolve every issue before preparing a ticket."
        return
    st.session_state.prepared = {"snapshot": snapshot(),
                                 "ticket": render_ticket(result, st.session_state.source_text),
                                 "json": ticket_json(result, st.session_state.source_text)}


def render_evidence(name):
    field = st.session_state.extraction["fields"].get(name, {})
    if field.get("evidence"):
        st.caption("From the inquiry")
        st.text(field["evidence"])
    elif st.session_state.mode == "live_ai":
        st.caption("Not stated in the inquiry")


def render_review(locked):
    state = st.session_state
    st.header("Review the details")
    if state.mode is None:
        st.info("Paste an inquiry, then extract it or start manual entry.")
        st.caption("Customer details, quantities and deadline will appear here.")
        return
    st.caption("Manual entry" if state.mode == "manual" else "AI proposal awaiting your review")
    if state.stale:
        st.error("The inquiry changed. Extract it again or start manual entry for the current inquiry.")
    st.text_input("Customer name", key="edit_customer_name", disabled=locked, on_change=invalidate)
    render_evidence("customer_name")
    st.text_input("Email or phone", key="edit_contact", disabled=locked, on_change=invalidate)
    render_evidence("contact")
    sizes_label, size_help = st.columns([3, 1])
    sizes_label.markdown("**Size quantities**")
    with size_help.popover("Size help"):
        st.write("Enter every size. Use 0 when none are needed. A blank quantity stays unknown.")
    for size, column in zip(SIZES, st.columns(3)):
        column.text_input(f"Size {size}", key=f"edit_size_{size}", disabled=locked, on_change=invalidate)
    render_evidence("sizes")
    total, deadline = st.columns(2)
    total.text_input("Requested quantity", key="edit_stated_total", placeholder="Unknown", disabled=locked, on_change=invalidate)
    deadline.text_input("Deadline", key="edit_deadline", placeholder="YYYY-MM-DD", disabled=locked, on_change=invalidate)
    with st.popover("Quantity and deadline help"):
        st.write("Requested quantity is optional. Leave it blank if the customer did not give a total. A deadline needs a complete date including the year and at least seven days of lead time.")
    render_evidence("stated_total")
    render_evidence("deadline")
    result, errors, questions, unresolved, _ = review_status()
    requested = result["fields"]["stated_total"]["value"]
    one, two = st.columns(2)
    one.metric("Requested quantity", "Unknown" if requested is None else requested)
    two.metric("Supplied size sum", "Unknown" if result["total"] is None else result["total"])
    missing = list(result["missing"])
    missing_sizes = [s for s in SIZES if not state[f"edit_size_{s}"].strip()]
    if missing_sizes:
        st.caption("Enter a quantity for " + ", ".join(missing_sizes) + ". Use 0 when none are needed.")
    st.caption(f"{len(missing)} missing fields · {len(unresolved)} unresolved issues")
    for error in errors + result["blocks"]:
        st.error(error.replace(" — ", ". "))
    if missing:
        st.warning("Still needed · " + ", ".join(missing))
    for question in dedupe_questions(result["blocks"], questions):
        key = issue_key(question)
        state[key] = state.issue_resolutions.get(key, False)
        st.checkbox("Resolved · " + question, key=key, disabled=locked, on_change=resolve_issue, args=(key,))
    st.checkbox("I reviewed all fields and resolved the issues.", key="reviewed",
                disabled=locked or state.stale, on_change=acknowledgment_changed)


def main():
    st.set_page_config(page_title="OrderReady | Checked intake tickets", page_icon="📋", layout="wide")
    initialize()
    state = st.session_state
    if state.mode is not None and state.source_text != state.draft_source:
        state.stale = True
        invalidate()
    if state.observed_snapshot is not None and state.observed_snapshot != snapshot():
        invalidate()
    result, errors, _, _, ready = review_status()
    if state.prepared and (state.prepared["snapshot"] != snapshot() or not ready):
        invalidate()
    locked = state.prepared is not None
    pending = state.pending is not None
    st.html("""<style>
    .st-key-header h1 {font-size:2rem; letter-spacing:-.04em; padding-bottom:0;}
    .st-key-header p {margin-bottom:0;}
    .st-key-workspace h2,.st-key-ticket h2 {font-size:1.25rem;}
    .st-key-inquiry,.st-key-review,.st-key-ticket {background:#fff; border:1px solid #D5CFC4; border-radius:12px; padding:24px;}
    .st-key-workspace label p {font-size:14px;}
    .st-key-workspace [data-testid="stCaptionContainer"],.st-key-header [data-testid="stCaptionContainer"] {opacity:1;} .st-key-workspace [data-testid="stCaptionContainer"] p,.st-key-header [data-testid="stCaptionContainer"] p {color:#625C53; opacity:1;}
    .st-key-workspace [data-testid="stMetricValue"] {font-size:1.5rem;}
    .st-key-header {margin-bottom:8px;}
    .st-key-loading .placeholder {height:40px; background:#E9E4DC; border-radius:6px; margin:8px 0 24px;}
    @media(max-width:640px) {.st-key-inquiry,.st-key-review,.st-key-ticket {padding:16px;}}
    </style>""")
    with st.container(key="header"):
        title, art = st.columns([3, 1])
        with title:
            st.title("OrderReady")
            st.write("Turn a customer inquiry into a checked intake ticket.")
            st.caption(SERVICE)
        with art:
            from intro import render_intro
            render_intro()
    with st.container(key="workspace"):
        inquiry, review = st.columns([1, 1.35], gap="large")
        with inquiry, st.container(key="inquiry"):
            st.header("Customer inquiry")
            st.text_area("Customer message", key="source_text", height=240,
                         placeholder="Paste the customer's message here", disabled=locked or pending,
                         on_change=source_changed)
            configured = live_ai_configured()
            if not configured:
                st.warning(UNAVAILABLE_MESSAGE)
            st.caption("Live extraction sends this message to Anthropic. Review the proposal before using it.")
            replacing = has_edits()
            disabled = locked or pending or not configured or not state.source_text.strip()
            st.button("Replace edits with AI extraction" if replacing else "Extract with AI",
                      key="extract", type="primary", on_click=run_extraction,
                      kwargs={"replace": replacing}, disabled=disabled, width="stretch")
            st.button("Start manual entry", key="manual", on_click=start_manual,
                      disabled=locked or pending or not state.source_text.strip(), width="stretch")
            if state.extraction_error:
                st.error(state.extraction_error)
                st.button("Retry extraction and replace edits" if replacing else "Retry extraction", key="retry",
                          on_click=run_extraction, kwargs={"fresh": True, "replace": replacing}, disabled=disabled)
            if state.cache_notice:
                st.info(state.cache_notice)
            with st.expander("Samples and extraction options"):
                samples = [{"label": case["id"], "input": case["text"]} for case in fixtures.CASES]
                st.selectbox("Sample inquiry", range(len(samples)), format_func=lambda i: samples[i]["label"],
                             key="sample_choice", disabled=locked or pending, on_change=invalidate)
                st.button("Load sample", key="load_sample", on_click=load_sample, args=(samples,), disabled=locked or pending)
                st.button("Replace edits with fresh extraction" if replacing else "Fresh extraction",
                          key="fresh", on_click=run_extraction, kwargs={"fresh": True, "replace": replacing}, disabled=disabled)
                st.caption("Fresh extraction makes a new AI request. Successful proposals are reused for 15 minutes in this session.")
            st.button("Reset intake", key="reset", on_click=reset, disabled=pending)
        with review, st.container(key="review"):
            if pending:
                st.header("Reading the inquiry.")
                st.caption("Your existing draft is kept until a new proposal is ready.")
                with st.container(key="loading"):
                    st.html('<div role="status" aria-label="Reading the inquiry"><div class="placeholder"></div><div class="placeholder"></div><div class="placeholder"></div><div class="placeholder"></div></div>')
            else:
                render_review(locked)
        if not pending:
            with st.container(key="ticket"):
                st.header("Intake ticket")
                if locked:
                    st.success("Ready for intake")
                    st.code(state.prepared["ticket"], language=None, wrap_lines=True)
                    st.download_button("Download intake ticket", state.prepared["ticket"], file_name="orderready-intake.txt",
                                       mime="text/plain", key="download", on_click="ignore")
                    st.button("Edit intake", key="edit_intake", on_click=invalidate)
                    with st.expander("Ticket as JSON"):
                        st.json(state.prepared["json"])
                else:
                    st.caption("Review the details and acknowledge your checks to prepare the ticket.")
                    st.button("Prepare intake ticket", key="prepare", on_click=prepare_ticket,
                              type="primary", disabled=not review_status()[-1])
                    if state.prepare_error:
                        st.error(state.prepare_error)
                st.caption(NONCOMMITMENT)
    with st.expander("Configuration and technical details"):
        st.write("AI provider is Anthropic. Live extraction requires ANTHROPIC_API_KEY.")
        st.write("Use synthetic inquiries. Intake stays in this app session. Provider retention is not verified.")
        st.caption("Unknown totals remain unknown. Every size requires an explicit quantity.")
    if state.history:
        with st.expander("Extraction history"):
            for index, entry in enumerate(state.history):
                st.write(f"Original proposal {index + 1}")
                st.text(entry["source_text"])
                st.json(readable_extraction(entry["extraction"]))
    if pending:
        # Detach omitted editor widget values before Streamlit's widget cleanup.
        for key in EDIT_KEYS:
            state[f"edit_{key}"] = state[f"edit_{key}"]
        consume_pending()
        state.observed_snapshot = snapshot()
        st.rerun()
    state.observed_snapshot = snapshot()


if __name__ == "__main__":
    main()
